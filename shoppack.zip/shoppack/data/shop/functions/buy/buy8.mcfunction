execute as @a[scores={diamond=..4,buyitem=8}] run tellraw @s {"text":"お前にはダイヤも頭も足りねぇよｗ","color":"red"}

execute as @a[scores={diamond=5..,buyitem=8}] run give @s gold_ingot 1
execute as @a[scores={diamond=5..,buyitem=8}] run clear @s diamond 5
execute as @a[scores={buyitem=8}] run scoreboard players set @s buyitem 0