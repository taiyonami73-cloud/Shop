execute as @a[scores={gold=..128,buyitem=4}] run tellraw @s {"text":"お前には金も頭も足りねぇよｗ","color":"red"}

execute as @a[scores={gold=128..,buyitem=4}] run give @s jujutsucraft:recommendation_1 1
execute as @a[scores={gold=128..,buyitem=4}] run clear @s gold_ingot 128
execute as @a[scores={buyitem=4}] run scoreboard players set @s buyitem 0