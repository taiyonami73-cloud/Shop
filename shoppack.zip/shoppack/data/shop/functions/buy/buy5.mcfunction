execute as @a[scores={gold=..255,buyitem=5}] run tellraw @s {"text":"お前には金も頭も足りねぇよｗ","color":"red"}

execute as @a[scores={gold=256..,buyitem=5}] run give @s jujutsucraft:recommendation_2 1
execute as @a[scores={gold=256..,buyitem=5}] run clear @s gold_ingot 256
execute as @a[scores={buyitem=5}] run scoreboard players set @s buyitem 0