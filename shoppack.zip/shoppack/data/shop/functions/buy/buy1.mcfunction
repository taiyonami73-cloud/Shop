execute as @a[scores={gold=..63,buyitem=1}] run tellraw @s {"text":"お前には金も頭も足りねぇよｗ","color":"red"}

execute as @a[scores={gold=64..,buyitem=1}] run give @s enchanted_golden_apple 1
execute as @a[scores={gold=64..,buyitem=1}] run clear @s gold_ingot 64
execute as @a[scores={buyitem=1}] run scoreboard players set @s buyitem 0