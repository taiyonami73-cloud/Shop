execute as @a[scores={gold=..63,buyitem=2}] run tellraw @s {"text":"お前には金も頭も足りねぇよｗ","color":"red"}

execute as @a[scores={gold=64..,buyitem=2}] run give @s jujutsucraft:item_master_reverse_cursed_technique 1
execute as @a[scores={gold=64..,buyitem=2}] run clear @s gold_ingot 64
execute as @a[scores={buyitem=2}] run scoreboard players set @s buyitem 0