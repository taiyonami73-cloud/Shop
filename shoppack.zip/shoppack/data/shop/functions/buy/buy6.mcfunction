execute as @a[scores={gold=..127,buyitem=6}] run tellraw @s {"text":"お前には金も頭も足りねぇよｗ","color":"red"}

execute as @a[scores={gold=128..,buyitem=6}] run give @s totem_of_undying 1
execute as @a[scores={gold=128..,buyitem=6}] run clear @s gold_ingot 128
execute as @a[scores={buyitem=6}] run scoreboard players set @s buyitem 0