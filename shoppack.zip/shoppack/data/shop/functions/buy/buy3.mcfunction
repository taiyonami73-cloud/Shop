execute as @a[scores={gold=..63,buyitem=3}] run tellraw @s {"text":"お前には金も頭も足りねぇよｗ","color":"red"}

execute as @a[scores={gold=64..,buyitem=3}] run give @s jujutsucraft:item_master_domain_expansion 1
execute as @a[scores={gold=64..,buyitem=3}] run clear @s gold_ingot 64
execute as @a[scores={buyitem=3}] run scoreboard players set @s buyitem 0