execute as @a[scores={gold=..127,buyitem=7}] run tellraw @s {"text":"お前には金も頭も足りねぇよｗ","color":"red"}

execute as @a[scores={gold=128..,buyitem=7}] run give @s jujutsucraft:item_master_six_eyes 1
execute as @a[scores={gold=128..,buyitem=7}] run clear @s gold_ingot 128
execute as @a[scores={buyitem=7}] run scoreboard players set @s buyitem 0