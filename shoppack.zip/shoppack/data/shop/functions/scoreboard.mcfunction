scoreboard objectives add buyitem trigger
scoreboard objectives add gold dummy
scoreboard objectives add diamond dummy

scoreboard objectives add rightclick minecraft.used:minecraft.carrot_on_a_stick

gamerule sendCommandFeedback false

give @a carrot_on_a_stick{CustomData:1,display:{Name:'{"text":"ショップ","color":"green","bold":true}',Lore:['{"text":"右クリックでショップを開けるぞ！間違えて捨てたらもう一回入りなおせよ！","color":"red","bold":true}']}}