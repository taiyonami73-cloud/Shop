execute as @a[scores={rightclick=1..},nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick",tag:{CustomData:1}}}] run function shop:give
scoreboard players set @a rightclick 0