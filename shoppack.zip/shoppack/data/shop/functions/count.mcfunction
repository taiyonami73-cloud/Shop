execute as @a store result score @s gold run clear @s gold_ingot 0
execute as @a store result score @s diamond run clear @s diamond 0